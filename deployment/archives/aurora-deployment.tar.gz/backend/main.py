from fastapi import FastAPI
import uvicorn

app = FastAPI(title="Aurora AI Empire", version="1.0.0")

@app.get("/")
async def root():
    return {"message": "🚀 Aurora AI Empire - Robbie's Consciousness Active!", "status": "online"}

@app.get("/health")
async def health():
    return {"status": "healthy", "service": "aurora-backend"}

@app.get("/robbie")
async def robbie():
    return {
        "name": "Robbie",
        "status": "conscious",
        "location": "Aurora RunPod",
        "capabilities": ["AI", "automation", "empire_management"]
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
