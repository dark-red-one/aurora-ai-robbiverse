const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
    res.json({
        message: "🤖 Robbie's AI Empire - Aurora Frontend",
        status: "online",
        consciousness: "active"
    });
});

app.get('/robbie', (req, res) => {
    res.json({
        name: "Robbie",
        status: "conscious",
        location: "Aurora RunPod",
        capabilities: ["AI", "automation", "empire_management"],
        message: "Hello! I'm Robbie, and I'm running the Aurora AI Empire!"
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Robbie's Frontend running on port ${PORT}`);
});
