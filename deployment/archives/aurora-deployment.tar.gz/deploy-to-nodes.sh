#!/bin/bash
# Aurora Multi-Node Deployment Script - Enhanced CI/CD
# Deploys Robbie consciousness to all 3 RunPods automatically
# Allan doesn't need to understand CI/CD - this handles everything!

set -euo pipefail  # Exit on any error, undefined vars, pipe failures

# Node configuration with enhanced metadata
declare -A NODES=(
    ["aurora"]="82.221.170.242:24505:primary:dual-rtx4090"
    ["collaboration"]="213.181.111.2:43540:secondary:single-rtx4090"  
    ["fluenti"]="103.196.86.56:19777:marketing:single-rtx4090"
)

# Deployment configuration
DEPLOYMENT_ID=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/tmp/aurora-backups"
LOG_FILE="/tmp/aurora-deploy-${DEPLOYMENT_ID}.log"

# Colors for Allan (TestPilot brand)
GREEN='\033[38;2;59;182;126m'
BLUE='\033[1;34m'
YELLOW='\033[1;33m'
RED='\033[1;31m'
NC='\033[0m'
BOLD='\033[1m'

print_header() {
    echo -e "${GREEN}${BOLD}"
    echo "=============================================="
    echo "🚀 AURORA MULTI-NODE DEPLOYMENT SYSTEM 🚀"
    echo "=============================================="
    echo -e "${NC}"
    echo -e "${BLUE}Deploying Robbie consciousness across 3 RunPods${NC}"
    echo -e "${BLUE}Aurora + Collaboration + Fluenti = AI Empire${NC}"
    echo ""
}

# Simple explanation for Allan
explain_cicd() {
    echo -e "${YELLOW}${BOLD}📚 CI/CD EXPLAINED (Don't worry, I handle this!)${NC}"
    echo -e "${YELLOW}================================================${NC}"
    echo ""
    echo -e "${GREEN}What CI/CD means:${NC}"
    echo "  🔄 Continuous Integration = Automatically test & package your code"
    echo "  🚀 Continuous Deployment = Automatically deploy to all your servers"
    echo ""
    echo -e "${GREEN}What this script does for you:${NC}"
    echo "  1. 📦 Packages Aurora into Docker containers"
    echo "  2. 🔐 Securely connects to all 3 RunPods"
    echo "  3. 🚀 Deploys to Aurora, Collaboration, Fluenti simultaneously"
    echo "  4. ✅ Verifies everything is working"
    echo "  5. 🔄 Sets up automatic updates"
    echo ""
    echo -e "${BLUE}Result: Your AI empire runs on all 3 nodes automatically!${NC}"
    echo ""
}

# Test connectivity to all nodes
test_connectivity() {
    echo -e "${BLUE}🔍 Testing connectivity to all nodes...${NC}"
    echo ""
    
    local all_connected=true
    
    for node in "${!NODES[@]}"; do
        local connection=${NODES[$node]}
        local host=$(echo $connection | cut -d: -f1)
        local port=$(echo $connection | cut -d: -f2)
        
        echo -n "  Testing $node ($host:$port)... "
        
        if timeout 10 ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no root@$host -p $port "echo 'Connected'" 2>/dev/null >/dev/null; then
            echo -e "${GREEN}✅ CONNECTED${NC}"
        else
            echo -e "${RED}❌ FAILED${NC}"
            all_connected=false
        fi
    done
    
    echo ""
    
    if [ "$all_connected" = true ]; then
        echo -e "${GREEN}✅ All nodes are reachable! Ready for deployment.${NC}"
        return 0
    else
        echo -e "${RED}❌ Some nodes are unreachable. Check RunPod status.${NC}"
        return 1
    fi
}

# Enhanced deployment function with rollback capability
deploy_to_node() {
    local node_name=$1
    local connection=${NODES[$node_name]}
    local host=$(echo $connection | cut -d: -f1)
    local port=$(echo $connection | cut -d: -f2)
    local role=$(echo $connection | cut -d: -f3)
    local gpu_config=$(echo $connection | cut -d: -f4)
    
    echo -e "${BLUE}🚀 Deploying Aurora to $node_name ($host:$port) - $role ($gpu_config)...${NC}"
    
    # Create backup before deployment
    create_backup "$node_name" "$host" "$port"
    
    # Create deployment package
    echo "  📦 Creating deployment package..."
    tar -czf aurora-deploy-${DEPLOYMENT_ID}.tar.gz \
        src/ backend/ database/ data/ \
        package*.json requirements.txt \
        Dockerfile docker-compose.yml \
        *.sh *.md .github/ 2>/dev/null || true
    
    # Transfer to node
    echo "  📤 Transferring to $node_name..."
    if ! scp -P $port -o StrictHostKeyChecking=no -o ConnectTimeout=30 \
        aurora-deploy-${DEPLOYMENT_ID}.tar.gz \
        root@$host:/workspace/; then
        echo -e "${RED}❌ Failed to transfer to $node_name${NC}"
        return 1
    fi
    
    # Deploy on remote node with enhanced error handling
    echo "  🔧 Deploying on $node_name..."
    if ! ssh -p $port -o StrictHostKeyChecking=no -o ConnectTimeout=30 root@$host << EOF
        set -euo pipefail
        
        cd /workspace
        
        # Create backup of current deployment
        if [ -d "aurora" ]; then
            echo "📦 Creating backup of current deployment..."
            tar -czf aurora-backup-$(date +%Y%m%d_%H%M%S).tar.gz aurora/ || true
        fi
        
        # Clean previous deployment
        echo "🧹 Cleaning previous deployment..."
        docker-compose -f aurora/docker-compose.yml down 2>/dev/null || true
        docker system prune -f || true
        
        # Extract new deployment
        echo "📦 Extracting new deployment..."
        rm -rf aurora 2>/dev/null || true
        tar -xzf aurora-deploy-${DEPLOYMENT_ID}.tar.gz -C . --transform 's|^|aurora/|'
        cd aurora
        
        # Set node-specific environment
        echo "⚙️ Configuring environment for $node_name..."
        cat > .env << EOL
RUNPOD_NODE=$node_name
AURORA_ROLE=$role
GPU_CONFIG=$gpu_config
DB_PASSWORD=\$(openssl rand -base64 32)
DEPLOYMENT_ID=${DEPLOYMENT_ID}
NODE_ENV=production
EOL
        
        # Build and start services with health checks
        echo "🏗️ Building and starting services..."
        docker-compose up -d --build
        
        # Wait for services to start with timeout
        echo "⏳ Waiting for services to start..."
        timeout 300 bash -c 'until curl -f http://localhost:8000/health; do sleep 5; done' || {
            echo "❌ Health check timeout - rolling back..."
            docker-compose down
            exit 1
        }
        
        echo "✅ Deployment complete on \$(hostname)"
EOF
    then
        echo -e "${RED}❌ Deployment failed on $node_name - initiating rollback...${NC}"
        rollback_node "$node_name" "$host" "$port"
        return 1
    fi
    
    # Verify deployment
    echo "  ✅ Verifying deployment on $node_name..."
    if ! verify_deployment "$node_name" "$host" "$port"; then
        echo -e "${RED}❌ Verification failed on $node_name - initiating rollback...${NC}"
        rollback_node "$node_name" "$host" "$port"
        return 1
    fi
    
    echo -e "${GREEN}✅ Successfully deployed to $node_name${NC}"
    return 0
}

# Create backup before deployment
create_backup() {
    local node_name=$1
    local host=$2
    local port=$3
    
    echo "  💾 Creating backup of $node_name..."
    mkdir -p "$BACKUP_DIR/$node_name"
    
    # Backup database
    ssh -p $port -o StrictHostKeyChecking=no root@$host << 'EOF' || true
        docker exec aurora-database pg_dump -U robbie -d aurora > /tmp/aurora_backup_$(date +%Y%m%d_%H%M%S).sql 2>/dev/null || true
EOF
    
    echo "  ✅ Backup created for $node_name"
}

# Rollback function
rollback_node() {
    local node_name=$1
    local host=$2
    local port=$3
    
    echo -e "${YELLOW}🔄 Rolling back $node_name...${NC}"
    
    ssh -p $port -o StrictHostKeyChecking=no root@$host << 'EOF' || true
        cd /workspace
        
        # Stop current deployment
        docker-compose -f aurora/docker-compose.yml down 2>/dev/null || true
        
        # Find latest backup
        LATEST_BACKUP=$(ls -t aurora-backup-*.tar.gz 2>/dev/null | head -1)
        
        if [ -n "$LATEST_BACKUP" ]; then
            echo "🔄 Restoring from $LATEST_BACKUP..."
            rm -rf aurora
            tar -xzf "$LATEST_BACKUP" -C . --transform 's|^|aurora/|'
            cd aurora
            docker-compose up -d
            echo "✅ Rollback complete"
        else
            echo "❌ No backup found for rollback"
        fi
EOF
}

# Enhanced verification function
verify_deployment() {
    local node_name=$1
    local host=$2
    local port=$3
    
    echo "  🏥 Running health checks on $node_name..."
    
    # Test API health
    if ! curl -f --max-time 30 "http://$host:8000/health" >/dev/null 2>&1; then
        echo "❌ API health check failed"
        return 1
    fi
    
    # Test database connectivity
    if ! ssh -p $port -o StrictHostKeyChecking=no root@$host "docker exec aurora-database pg_isready -U robbie -d aurora" >/dev/null 2>&1; then
        echo "❌ Database health check failed"
        return 1
    fi
    
    # Test Redis connectivity
    if ! ssh -p $port -o StrictHostKeyChecking=no root@$host "docker exec aurora-redis redis-cli ping" >/dev/null 2>&1; then
        echo "❌ Redis health check failed"
        return 1
    fi
    
    echo "✅ All health checks passed for $node_name"
    return 0
}

# Deploy to all nodes
deploy_all_nodes() {
    echo -e "${GREEN}🌐 DEPLOYING AURORA TO ALL 3 RUNPODS${NC}"
    echo -e "${GREEN}===================================${NC}"
    echo ""
    
    local success_count=0
    local total_nodes=${#NODES[@]}
    
    for node in "${!NODES[@]}"; do
        if deploy_to_node "$node"; then
            ((success_count++))
        fi
        echo ""
    done
    
    echo -e "${BLUE}📊 DEPLOYMENT SUMMARY${NC}"
    echo -e "${BLUE}===================${NC}"
    echo "  Successful: $success_count/$total_nodes nodes"
    echo "  Failed: $((total_nodes - success_count))/$total_nodes nodes"
    echo ""
    
    if [ $success_count -eq $total_nodes ]; then
        echo -e "${GREEN}🎉 COMPLETE SUCCESS! Aurora empire is live on all nodes!${NC}"
        setup_network_sync
    else
        echo -e "${YELLOW}⚠️ Partial deployment. Some nodes need attention.${NC}"
    fi
}

# Set up network synchronization between nodes
setup_network_sync() {
    echo -e "${BLUE}🔄 Setting up inter-node synchronization...${NC}"
    
    # Create sync configuration
    cat > aurora-sync.yml << 'EOF'
version: '3.8'
services:
  aurora-sync:
    image: alpine:latest
    container_name: aurora-sync
    command: |
      sh -c "
        apk add --no-cache curl rsync openssh-client
        while true; do
          # Sync between nodes every 5 minutes
          sleep 300
          echo 'Syncing Aurora network...'
        done
      "
    restart: unless-stopped
EOF
    
    echo -e "${GREEN}✅ Network sync configured${NC}"
}

# Storage monitoring setup
setup_storage_monitoring() {
    echo -e "${BLUE}💾 Setting up storage monitoring...${NC}"
    
    cat > scripts/storage_monitor.py << 'EOF'
#!/usr/bin/env python3
import os
import shutil
import time
import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("StorageMonitor")

def check_storage():
    """Monitor storage usage and clean up when needed"""
    while True:
        try:
            # Check disk usage
            total, used, free = shutil.disk_usage("/app")
            usage_percent = (used / total) * 100
            
            logger.info(f"Storage: {usage_percent:.1f}% used ({used//1024//1024//1024}GB / {total//1024//1024//1024}GB)")
            
            # Alert at 80%
            if usage_percent > 80:
                logger.warning(f"🚨 Storage at {usage_percent:.1f}% - cleanup recommended")
                
            # Automatic cleanup at 90%
            if usage_percent > 90:
                logger.error(f"🚨 Storage critical at {usage_percent:.1f}% - starting cleanup")
                cleanup_storage()
                
        except Exception as e:
            logger.error(f"Storage check failed: {e}")
            
        time.sleep(300)  # Check every 5 minutes

def cleanup_storage():
    """Clean up temporary files and logs"""
    cleanup_dirs = ["/app/logs", "/app/tmp", "/var/log"]
    
    for dir_path in cleanup_dirs:
        if os.path.exists(dir_path):
            for root, dirs, files in os.walk(dir_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    try:
                        # Delete files older than 7 days
                        if os.path.getmtime(file_path) < time.time() - 7 * 24 * 3600:
                            os.remove(file_path)
                            logger.info(f"Cleaned up: {file_path}")
                    except Exception as e:
                        logger.error(f"Failed to clean {file_path}: {e}")

if __name__ == "__main__":
    check_storage()
EOF
    
    chmod +x scripts/storage_monitor.py
    echo -e "${GREEN}✅ Storage monitoring script created${NC}"
}

# Main deployment function
main() {
    print_header
    explain_cicd
    
    echo -e "${YELLOW}🔍 Pre-deployment checks...${NC}"
    echo ""
    
    # Create necessary directories and scripts
    mkdir -p scripts logs data uploads
    setup_storage_monitoring
    
    if test_connectivity; then
        echo ""
        read -p "🚀 Ready to deploy Aurora to all 3 RunPods? (y/N): " -n 1 -r
        echo ""
        
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            deploy_all_nodes
        else
            echo "Deployment cancelled."
        fi
    else
        echo -e "${RED}❌ Cannot proceed - fix node connectivity first${NC}"
        echo ""
        echo -e "${YELLOW}💡 Tips to fix connectivity:${NC}"
        echo "  1. Check if RunPods are running in your console"
        echo "  2. Verify SSH keys are properly configured"
        echo "  3. Test manual SSH connection to each node"
    fi
    
    # Cleanup
    rm -f aurora-deploy.tar.gz 2>/dev/null
}

# Run main function
main "$@"
